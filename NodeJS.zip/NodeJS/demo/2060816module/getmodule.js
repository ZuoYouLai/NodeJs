
var mu=require('./module');
mu.setName("Mr.lai");
mu.sayHello();