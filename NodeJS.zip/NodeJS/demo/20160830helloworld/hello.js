console.log("hello nodeJs");
console.log('%s:%d','hello',23);